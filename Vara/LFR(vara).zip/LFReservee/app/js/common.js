$(function() {
  // Мобільна панелька
	$('#my-menu').mmenu({
	extensions:['widescreen', 'theme-white', 'effect-menu-slider', 'pagedim-black', 'position-right'],
	navbar:{
		title:'<img src="img/logopannel.png">'
	}
});
var API = $('#my-menu').data('mmenu');
  var $icon = $('.hamburger');
 
   API.bind( "open:finish", function()
   {
      setTimeout(function() 
      {
        $icon.addClass( "is-active" );
      }, 10);
   });

   API.bind( "close:finish", function() 
   {
      setTimeout(function() 
      {
        $icon.removeClass( "is-active" );
      }, 10);
   });﻿
// Каруселька команда

$('.carousel-team').owlCarousel({
  loop: true,
  nav: true,
  smartSpeed: 700,
  navText:['<i class="las la-angle-left"></i>', '<i class="las la-angle-right"></i>'],
  responsiveClass: true,
  dots: true,
  autoplay:false,
    autoplayTimeout:3000,
    autoplayHoverPause:true,
  responsive:{
    0: {
      items: 1
    }
  }
  
})
// Фільтер на курси
var mixer = mixitup('.courses-container');
mixer.filter('.category-a');
// Кнопка більще-менше курсів
$("#moreEnglish").click(function(){
  $(".english-second-row").toggle(1000);
});
$("#moreArabican").click(function(){
  $(".arabican-second-row").toggle(1000);
});
$("#moreItalian").click(function(){
  $(".italian-second-row").toggle(1000);
});
// Плавна навігація
$('a[data-target^="anchor"]').bind("click.smoothscroll", function(){
    var target = $(this).attr('href'),
      bl_top = $(target).offset().top;
    $('body, html').animate({scrollTop: bl_top}, 1500);
    return false;
  })
// Анімація на певному момені прокрутки сторінки
var b = 0;
$(window).scroll(function() {
  var oTop = $('.site-title-about').offset().top - window.innerHeight;
  if (b == 0 && $(window).scrollTop() > oTop) {
      $('.site-title-about').css('animation', 'slide-in-bottom  0.5s');
      $('.about-container-left').css('animation', 'slide-in-bottom  0.75s');
      $('.about-container-right').css('animation', 'slide-in-bottom  0.75s');
  }
});
var c = 0;
$(window).scroll(function() {
  var oTop = $('.site-title-team').offset().top - window.innerHeight;
  if (c == 0 && $(window).scrollTop() > oTop) {
      $('.site-title-team').css('animation', 'slide-in-bottom  0.5s');
      $('.carousel-team').css('animation', 'slide-in-bottom  0.75s');

  }
});
var d = 0;
$(window).scroll(function() {
  var oTop = $('.site-title-courses').offset().top - window.innerHeight;
  if (d == 0 && $(window).scrollTop() > oTop) {
      $('.site-title-courses').css('animation', 'slide-in-bottom  0.5s');
      $('.courses-buttons').css('animation', 'slide-in-bottom  0.75s');
      $('.courses-container').css('animation', 'slide-in-bottom  0.75s');
  }
});

});
